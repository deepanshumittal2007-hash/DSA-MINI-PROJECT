# DSA Mini Projects — PPF Week 9

This repository bundle contains both projects listed in the supplied assignment PDF:

1. `campus_route_finder/` — Campus Route Finder using a graph, adjacency list, BFS, DFS, and reachability checks.
2. `student_record_bst/` — Student Record Search System using a BST, insertion, search, deletion, and traversals.

Each project folder includes C++ source code, build/run instructions, test cases, complexity analysis, and a short report. Capture screenshots from your own runs before final submission; the README files list the required screenshots.

## Requirements
- A C++ compiler supporting C++17 (g++ recommended).
- A terminal or command prompt.

## GitHub upload
Create a new GitHub repository, e.g. `dsa-week9-mini-projects`, then upload all files/folders in this directory. Do not upload the ZIP itself if your instructor expects browsable source files; extract it first and upload the extracted contents.
