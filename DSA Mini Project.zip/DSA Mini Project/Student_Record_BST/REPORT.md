# Mini Project Report: Student Record Search System Using Trees

## Aim
To implement a menu-driven student record manager using a Binary Search Tree keyed by unique enrolment ID.

## Data structure
Each node stores an integer enrolment ID, student name, department/programme, and pointers to left/right children. For each node, smaller IDs are stored in the left subtree and larger IDs in the right subtree. Duplicate IDs are rejected.

## Operations
- **Insertion:** Walk left or right according to the key until an empty child pointer is found.
- **Search:** Compare the target ID with each visited node and follow the appropriate child.
- **Deletion:** A leaf is removed directly; a node with one child is replaced by that child; a node with two children is replaced by its inorder successor (minimum key in its right subtree), which is then deleted.
- **Traversals:** Inorder produces ascending IDs; preorder visits root-left-right; postorder visits left-right-root.

## Complexity and tree shape
Insert/search/delete take O(h), where h is tree height. Average behaviour is O(log n) for suitably shaped trees, but sorted insertion can create a chain and lead to O(n) worst-case operations. AVL trees use rotations to maintain logarithmic height and O(log n) core operations.

## Test plan
1. Insert IDs 50, 30, 70, 20, 40, 60, 80, 10, 25, 35.
2. Insert a duplicate ID such as 30; it must be rejected.
3. Search for 40 (found) and 999 (not found).
4. Delete leaf 25; verify it no longer appears in inorder traversal.
5. For one-child deletion, use a fresh tree with IDs 20, 10, 30, 25, then delete 30; 25 must remain.
6. For two-child deletion, use a fresh tree with IDs 20, 10, 30, 25, 35, then delete 30; inorder must remain sorted and contain all other IDs.
7. Compare insertion-comparison counts for the two orders printed by option 7.

## Privacy note
Use fictional student data in screenshots and demonstrations unless you have permission to share real records.
